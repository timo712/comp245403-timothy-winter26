package Ex3;

import java.io.File;

public class RecursiveFind {
    public static void find(String path, String filename)
    {
        File file = new File(path);

        if (!file.exists())
        {
            System.out.println("Path does not exist.");
            return;
        }

        if(file.isDirectory())
        {
           if(file.getName().equals(filename))
           {
               System.out.println("Found: " + file.getAbsolutePath());
           }
           return;
        }

        if(file.isDirectory())
        {
            File[] files = file.listFiles();

            if(files != null)
            {
                for(File f : files)
                {
                    find(f.getAbsolutePath(), filename);
                }
            }
        }
    }

    public static void main(String[] args)
    {
        String startPath = "C:\\Users\\ YourName\\Documents";

        String  targerFile = "example.txt";

        find(startPath,targerFile);
    }
}
