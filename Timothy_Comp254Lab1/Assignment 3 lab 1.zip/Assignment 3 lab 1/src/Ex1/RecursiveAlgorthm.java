package Ex1;

public class RecursiveAlgorthm {

    public static int multiply(int m, int n)
    {
        if (n == 0)
        {
            return 0;
        }else
        {
            return m + multiply(m, n-1);
        }
    }

    public static int addition(int m, int n)
    {
        if(n == 0)
        {
            return 1;
        }else
        {
            return m + addition( m, n-1);
        }
    }

    public static void main (String[] args)
    {
        int Final = multiply(4,5);

        int Final1 = addition(4,5);

        System.out.println("The Result:" + Final);

        System.out.println("The Result:" + Final1);
    }
}
